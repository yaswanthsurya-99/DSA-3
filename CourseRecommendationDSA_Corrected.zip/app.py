from flask import Flask, render_template, request, jsonify
import json, os, math, heapq
from collections import deque

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(BASE_DIR, "courses.json"), encoding="utf-8") as f:
    COURSES = json.load(f)
COURSE_MAP = {c["id"]: c for c in COURSES}
VALID_YEARS = {1,2,3,4}

def year_value(v):
    try:
        y=int(v); return y if y in VALID_YEARS else None
    except (TypeError,ValueError): return None

def tokens(text): return set(str(text).lower().replace(',', ' ').split())

def cosine(a,b):
    x,y=tokens(a),tokens(b)
    return 0.0 if not x or not y else len(x&y)/math.sqrt(len(x)*len(y))

def kmp(text,pattern):
    text,pattern=text.lower(),pattern.lower()
    if not pattern: return True
    lps=[0]*len(pattern); j=0
    for i in range(1,len(pattern)):
        while j and pattern[i]!=pattern[j]: j=lps[j-1]
        if pattern[i]==pattern[j]: j+=1
        lps[i]=j
    i=j=0
    while i<len(text):
        if text[i]==pattern[j]: i+=1; j+=1
        if j==len(pattern): return True
        if i<len(text) and text[i]!=pattern[j]:
            if j: j=lps[j-1]
            else: i+=1
    return False

class TrieNode:
    def __init__(self): self.children={}; self.end=False
class Trie:
    def __init__(self): self.root=TrieNode()
    def insert(self,w):
        n=self.root
        for ch in w.lower(): n=n.children.setdefault(ch,TrieNode())
        n.end=True
    def starts(self,p):
        n=self.root
        for ch in p.lower():
            if ch not in n.children: return False
            n=n.children[ch]
        return True
TRIE=Trie()
for c in COURSES: TRIE.insert(c['title'])

def score(c,interests,skills):
    text=c['title']+' '+c['description']+' '+' '.join(c['skills'])
    return round((cosine(interests,text)*.6+cosine(skills,' '.join(c['skills']))*.4)*100,2)

def recommend(year,interests,skills,completed):
    heap=[]
    for c in COURSES:
        if c['year']!=year: continue
        missing=[p for p in c.get('prerequisites',[]) if p not in completed]
        s=score(c,interests,skills)
        # completed prerequisites receive a small ranking bonus
        if not missing: s=min(100,s+5)
        heapq.heappush(heap,(-s,c['id'],c,missing))
    out=[]
    while heap and len(out)<10:
        ns,_,c,missing=heapq.heappop(heap); item=dict(c); item['score']=round(-ns,2); item['missing_prerequisites']=missing; out.append(item)
    return out

def study_order(year):
    graph={c['id']:[] for c in COURSES if c['year']==year}; indeg={k:0 for k in graph}
    for c in COURSES:
        if c['year']!=year: continue
        for p in c.get('prerequisites',[]):
            if p in graph: graph[p].append(c['id']); indeg[c['id']]+=1
    q=deque([k for k,v in indeg.items() if v==0]); out=[]
    while q:
        u=q.popleft(); out.append(COURSE_MAP[u]['title'])
        for v in graph[u]:
            indeg[v]-=1
            if indeg[v]==0:q.append(v)
    return out

@app.route('/')
def home(): return render_template('index.html')

@app.route('/api/courses')
def courses():
    y=year_value(request.args.get('year'))
    if y is None:return jsonify(error='Please select Year 1, 2, 3 or 4.'),400
    cs=[c for c in COURSES if c['year']==y]
    return jsonify(year=y,count=len(cs),courses=cs)

@app.route('/api/prerequisites')
def prerequisites():
    y=year_value(request.args.get('year'))
    if y is None:return jsonify(error='Invalid year.'),400
    if y==1:return jsonify(year=1,courses=[])
    cs=[c for c in COURSES if c['year']==y-1]
    return jsonify(year=y, prerequisite_year=y-1, courses=cs)

@app.route('/api/recommend',methods=['POST'])
def recommendations():
    d=request.get_json(silent=True) or {}; y=year_value(d.get('year'))
    interests=str(d.get('interests','')).strip(); skills=str(d.get('skills','')).strip()
    completed=set(str(x).upper() for x in (d.get('completed_prerequisites') or []))
    if y is None:return jsonify(error='Invalid year.'),400
    if not interests and not skills:return jsonify(error='Enter at least one interest or skill.'),400
    return jsonify(year=y,recommendations=recommend(y,interests,skills,completed))

@app.route('/api/search')
def search():
    y=year_value(request.args.get('year')); q=str(request.args.get('q','')).strip()
    if y is None:return jsonify(error='Invalid year.'),400
    return jsonify(results=[c for c in COURSES if c['year']==y and kmp(c['title']+' '+c['description']+' '+' '.join(c['skills']),q)])

@app.route('/api/autocomplete')
def autocomplete():
    y=year_value(request.args.get('year')); q=str(request.args.get('q','')).strip().lower()
    return jsonify(results=[c['title'] for c in COURSES if y and c['year']==y and c['title'].lower().startswith(q)][:8])

@app.route('/api/study-order')
def order():
    y=year_value(request.args.get('year'))
    if y is None:return jsonify(error='Invalid year.'),400
    return jsonify(year=y,study_order=study_order(y))

@app.route('/api/stats')
def stats():
    return jsonify(total_courses=len(COURSES),year_counts={str(y):sum(c['year']==y for c in COURSES) for y in range(1,5)})

if __name__=='__main__': app.run(host='127.0.0.1',port=5000,debug=True)
